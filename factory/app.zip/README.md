# Factory

## Objectif

Vous avez 3 type de véhicule disponible. Essayer de créer une interface commune, puis de créer une factory pour obtenir l'un des trois moyen de transports.

Vous pourrez dans un second temps créer une deuxieme methode dans cette Factory pour obtenir un vehicule en fonction de la distance et du poids transporter (si <20km, c'est le velo, sinon c'est la voiture. Si il y a plus de 20kg ça sera la voiture et si plus de 200kg le camion.)
