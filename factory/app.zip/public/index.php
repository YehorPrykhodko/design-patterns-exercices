<?php
require('../vendor/autoload.php');

# Essayer d'utiliser votre factory ici